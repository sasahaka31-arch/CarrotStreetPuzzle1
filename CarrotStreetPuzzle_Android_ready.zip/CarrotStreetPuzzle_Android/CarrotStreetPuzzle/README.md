# Carrot Street Puzzle — Android

Оригинальная Android-игра в жанре пошаговой головоломки. Проект не использует название, персонажей, графику или код Bobby Carrot.

## Как открыть
1. Распакуйте ZIP.
2. В Android Studio выберите **File → Open** и откройте папку **CarrotStreetPuzzle** (именно эту папку, где лежат `settings.gradle` и `build.gradle`).
3. Дождитесь окончания Gradle Sync. Интернет при первом открытии может потребоваться для загрузки Android Gradle Plugin и зависимостей.

## Как получить APK для телефона
Для обычной установки на телефон: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

Готовый отладочный APK появится примерно здесь:
`app/build/outputs/apk/debug/app-debug.apk`

Его можно передать на Android-телефон и установить. Если Android покажет предупреждение о разрешении установки из неизвестного источника, разрешите установку для приложения, через которое открываете APK (например, файлового менеджера).

## Как подготовить релиз для Google Play
Для публикации в Google Play используйте **Build → Generate Signed Bundle / APK → Android App Bundle**, создайте собственный keystore и соберите подписанный release `.aab`. Для платного приложения цену задают в Google Play Console.

## Технические настройки
- Android only
- minSdk 24
- targetSdk 35
- compileSdk 35
- Java 17
- package/applicationId: `com.example.carrotstreetpuzzle`
- портретный режим
- без рекламы и обязательного интернета
