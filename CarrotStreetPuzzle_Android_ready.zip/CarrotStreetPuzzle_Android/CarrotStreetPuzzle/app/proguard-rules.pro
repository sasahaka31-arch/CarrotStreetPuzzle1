# Keep default rules; no custom shrinking rules required.
